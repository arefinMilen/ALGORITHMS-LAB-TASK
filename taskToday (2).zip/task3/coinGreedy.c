#include <stdio.h>

void coinChange(int coins[], int numCoins, int amount) {
    int count = 0;

    for (int i = 0; i < numCoins; i++) {
        while (amount >= coins[i]) {
            printf("%d ", coins[i]);
            amount -= coins[i];
            count++;
        }
    }

    printf("\nMinimum number of coins: %d\n", count);
}

int main() {
    int numCoins;

    printf("Enter  no of coins: ");
    scanf("%d", &numCoins);

    int coins[numCoins];
    printf("coin elements :");
    for (int i = 0; i < numCoins; i++) {
        //printf("coin elements : ", i + 1);
        scanf("%d", &coins[i]);
    }

    int amount;
    printf("Enter the desired sum: ");
    scanf("%d", &amount);

    printf("The coins are: ");
    coinChange(coins, numCoins, amount);

    return 0;
}

