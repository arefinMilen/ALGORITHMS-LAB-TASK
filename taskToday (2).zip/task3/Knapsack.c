#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int weight;
    int profit;
    float ratio; // profit-to-weight ratio
} Item;

int compare(const void *a, const void *b) {
    Item *itemA = (Item *)a;
    Item *itemB = (Item *)b;
    return itemB->ratio - itemA->ratio;
}

float fractionalKnapsack(int capacity, Item items[], int numItems) {
    qsort(items, numItems, sizeof(Item), compare);

    float totalProfit = 0.0;
    int currentWeight = 0;

    for (int i = 0; i < numItems; i++) {
        if (currentWeight + items[i].weight <= capacity) {
            totalProfit += items[i].profit;
            currentWeight += items[i].weight;
        } else {
            float remainingWeight = capacity - currentWeight;
            totalProfit += (remainingWeight / items[i].weight) * items[i].profit;
            break;
        }
    }

    return totalProfit;
}

int main() {
    int numItems;

    printf("No of items: ");
    scanf("%d", &numItems);

    Item items[numItems];
    printf("given weights:");
    for (int i = 0; i < numItems; i++) {
       //printf("Enter weight and profit for item %d: ", i + 1);
        scanf("%d %d", &items[i].weight, &items[i].profit);
        items[i].ratio = (float)items[i].profit / items[i].weight;
    }

    int capacity;
    printf("given profit: ");
    scanf("%d", &capacity);

    float maxProfit = fractionalKnapsack(capacity, items, numItems);
    printf("Maximum profit: %.2f\n", maxProfit);

    return 0;
}


