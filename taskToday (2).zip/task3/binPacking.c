#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b) {
    return (*(int *)b - *(int *)a);
}

int binPacking(int weights[], int numWeights, int binCapacity) {
    qsort(weights, numWeights, sizeof(int), compare);

    int binCount = 0;
    int currentBinCapacity = 0;

    for (int i = 0; i < numWeights; i++) {
        if (currentBinCapacity + weights[i] <= binCapacity) {
            currentBinCapacity += weights[i];
        } else {
            binCount++;
            currentBinCapacity = weights[i];
        }
    }

    return binCount + 1;  // Adding 1 to account for the last bin
}

int main() {
    int numWeights;

    printf("no of weights to be packed: ");
    scanf("%d", &numWeights);

    int weights[numWeights];
    printf("given weights: ");
    for (int i = 0; i < numWeights; i++) {
        //printf("given weights : ", i + 1);
        scanf("%d", &weights[i]);
    }

    int binCapacity;
    printf("Bin capacity: ");
    scanf("%d", &binCapacity);

    int minBins = binPacking(weights, numWeights, binCapacity);
    printf("minimum number of bins: %d\n", minBins);

    return 0;
}


