#include <stdio.h>


int main() {
    char str[100];
    printf("Input: ");

    gets(str);


    int length = strlen(str);

    for (int i = 0; i < length; i++) {

        if (str[i] >= 'a' && str[i] < 'z')
            putchar(str[i] + 1);
        else if (str[i] == 'z')
            putchar('a');
        else if (str[i] >= 'A' && str[i] < 'Z')
            putchar(str[i] + 1);
        else if (str[i] == 'Z')
            putchar('A');
        else
            putchar(str[i]);
    }

    return 0;
}

