#include <stdio.h>


int main() {
    char input[100],n,i;

    printf("Case: ");
    scanf("%d", &n);
    for(i=0; i<n; i++)
    {
        gets(input);
    }
    for(i=0; i<n; i++)
    {
        char temp = input[i];

    if (isalpha(temp)) {
        printf("%c is an Alphabet: ",temp);


        temp = toupper(temp);

        if (temp == 'A' || temp == 'E' || temp == 'I' || temp == 'O' || temp == 'U') {
            printf("It's a Vowel.\n");
        } else {
            printf("It's a Consonant.\n");
        }
    }  if (isdigit(temp)) {
        printf("%c is a Digit.\n",temp);
    } else {
        printf("%c is a Special Character.\n",temp);
    }
    }

    return 0;
}


