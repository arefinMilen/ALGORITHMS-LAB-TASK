//Recursive approach
#include <stdio.h>

int isPalindromeRecursive(int num, int original) {
    if (num == 0) {
        return original == 0;
    }

    int digit = num % 10;
    return digit == original % 10 && isPalindromeRecursive(num / 10, original / 10);
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    if (isPalindromeRecursive(num, num)) {
        printf("%d is a palindrome number.\n", num);
    } else {
        printf("%d is not a palindrome number.\n", num);
    }

    return 0;
}
/*Time Complexity: O(log N), where N is the input number.
Space Complexity: O(log N), due to the recursive call stack.
*/

