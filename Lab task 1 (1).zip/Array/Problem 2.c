#include <stdio.h>

int linearSearch(int array[], int size, int target) {
    for (int i = 0; i < size; i++) {
        if (array[i] == target) {
            return i; // Return the index if element is found
        }
    }
    return -1; // Return -1 if element is not found
}

int main() {
    int t; // Number of test cases
    printf("Enter the number of test cases: ");
    scanf("%d", &t);

    while (t--) {
        int size;
        printf("How many numbers you want to insert? ");
        scanf("%d", &size);

        int array[size];
        printf("Enter %d array elements:\n", size);
        for (int i = 0; i < size; i++) {
            scanf("%d", &array[i]);
        }

        int target;
        printf("Enter data you want to search:\n");
        scanf("%d", &target);

        int result = linearSearch(array, size, target);
        if (result != -1) {
            printf("%d is found at index %d\n", target, result);
        } else {
            printf("%d is not found in the array\n", target);
        }
    }

    return 0;
}

