#include <stdio.h>

int main() {
    int size;

    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int array[size];

    printf("Enter %d integer numbers:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &array[i]);
    }

    printf("Positive numbers: ");
    for (int i = 0; i < size; i++) {
        if (array[i] > 0) {
            printf("%d ", array[i]);
        }
    }
    printf("\n");

    printf("Negative numbers: ");
    for (int i = 0; i < size; i++) {
        if (array[i] < 0) {
            printf("%d ", array[i]);
        }
    }
    printf("\n");

    return 0;
}

